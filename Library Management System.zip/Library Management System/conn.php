<?php
define("DBHOST","localhost");
define("DBUSERNAME","root");
define("DBPASSWORD","");
define("DB","Library Management System");
$conn = mysqli_connect(DBHOST,DBUSERNAME,DBPASSWORD,DB);
?>
